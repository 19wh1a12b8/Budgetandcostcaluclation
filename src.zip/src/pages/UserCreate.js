// import React, { useState } from "react";
// import axios from "axios";
// import "../Styles/User.css";

// function UserCreate() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [totalIncome, setTotalIncome] = useState("");
//   const [successMessage, setSuccessMessage] = useState("");
//   const [errorMessage, setErrorMessage] = useState("");
//   const [isLoading, setIsLoading] = useState(false);

//   const createUser = () => {
//     setIsLoading(true);

//     const newUser = {
//       username: username,
//       password: password,
//       totalIncome: parseFloat(totalIncome),
//     };

//     axios
//       .post("http://localhost:8281/users", newUser)
//       .then((response) => {
//         setSuccessMessage("User created successfully!");
//         setErrorMessage("");
//       })
//       .catch((error) => {
//         setErrorMessage("Error creating user. Please check your inputs and try again.");
//         setSuccessMessage("");
//       })
//       .finally(() => {
//         setIsLoading(false);
//       });
//   };

//   return (
//     <div className="container mt-5">
//       <div className="row justify-content-center">
//         <div className="col-md-6">
//           <div className="card p-4" style={cardStyle}>
//             <h2 style={titleStyle}>Create User</h2>

//             <div className="form-group">
//               <label style={labelStyle}>Username:</label>
//               <input
//                 type="text"
//                 className="form-control"
//                 style={inputStyle}
//                 value={username}
//                 onChange={(e) => setUsername(e.target.value)}
//               />
//             </div>

//             <div className="form-group">
//               <label style={labelStyle}>Password:</label>
//               <input
//                 type="password"
//                 className="form-control"
//                 style={inputStyle}
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//               />
//             </div>

//             <div className="form-group">
//               <label style={labelStyle}>Total Income:</label>
//               <input
//                 type="number"
//                 className="form-control"
//                 style={inputStyle}
//                 value={totalIncome}
//                 onChange={(e) => setTotalIncome(e.target.value)}
//               />
//             </div>

//             <button
//               type="button"
//               className="btn btn-primary"
//               style={buttonStyle}
//               onClick={createUser}
//               disabled={isLoading}
//             >
//               Create User
//             </button>

//             {isLoading ? <p>Loading...</p> : null}
//             {successMessage && <p style={successStyle}>{successMessage}</p>}
//             {errorMessage && <p style={errorStyle}>{errorMessage}</p>}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default UserCreate;

// const cardStyle = {
//   background: "white",
//   border: "1px solid #ccc",
//   borderRadius: "5px",
//   boxShadow: "0 0 5px 0 #ccc",
//   padding: "20px",
//   maxWidth: "450px",
// };

// const titleStyle = {
//   fontSize: "24px",
//   margin: "10px 0 0 0",
//   fontWeight: "lighter",
//   textTransform: "uppercase",
//   color: "#333",
// };

// const labelStyle = {
//   fontSize: "14px",
//   color: "#333",
//   fontWeight: "bold",
// };

// const inputStyle = {
//   padding: "10px",
//   fontSize: "16px",
//   border: "1px solid #ccc",
//   borderRadius: "5px",
// };

// const buttonStyle = {
//   backgroundColor: "#007BFF",
//   color: "white",
//   border: "none",
//   cursor: "pointer",
// };

// const successStyle = {
//   color: "#28a745",
// };

// const errorStyle = {
//   color: "#dc3545",
// };