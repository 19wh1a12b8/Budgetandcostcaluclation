import React, { useState } from "react";
import axios from "axios";
import "../Styles/Investment.css";

function Investment() {
  const [investmentId, setInvestmentId] = useState("");
  const [investmentProjection, setInvestmentProjection] = useState(null);
  const [annualInterestRate, setAnnualInterestRate] = useState(0.05);
  const [compoundingFrequency, setCompoundingFrequency] = useState(12);
  const [investmentPeriod, setInvestmentPeriod] = useState(5);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const calculateInvestmentGrowthProjection = () => {
    setIsLoading(true);

    axios
      .get(`http://localhost:8281/investments/${investmentId}/growthProjection`, {
        params: {
          annualInterestRate: annualInterestRate,
          compoundingFrequency: compoundingFrequency,
          investmentPeriod: investmentPeriod,
        },
      })
      .then((response) => {
        setInvestmentProjection(response.data);
        setError(null); // Clear any previous errors
      })
      .catch((error) => {
        setError("Error fetching data. Please check your inputs and try again.");
        console.error("Error fetching data:", error);
      })
      .finally(() => {
        setIsLoading(false); // Clear loading state
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateInvestmentGrowthProjection();
  };

  return (
    <div className="center-container mt-5 tb-5">
      <div className="investment-card p-4 bg-light ">
        <h2>Investment Growth Projection</h2>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Investment ID:</label>
            <input
              type="text"
              className="form-control"
              value={investmentId}
              onChange={(e) => setInvestmentId(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Annual Interest Rate:</label>
            <input
              type="number"
              step="0.01"
              className="form-control"
              value={annualInterestRate}
              onChange={(e) => setAnnualInterestRate(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Compounding Frequency:</label>
            <input
              type="number"
              className="form-control"
              value={compoundingFrequency}
              onChange={(e) => setCompoundingFrequency(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Investment Period (years):</label>
            <input
              type="number"
              className="form-control"
              value={investmentPeriod}
              onChange={(e) => setInvestmentPeriod(e.target.value)}
            />
          </div>

          <button type="submit" className="btn">
            Calculate
          </button>
        </form>

        {isLoading ? (
          <p>Loading...</p>
        ) : error ? (
          <p className="error-message">{error}</p>
        ) : investmentProjection !== null ? (
          <p>Projected Growth: {investmentProjection}</p>
        ) : null}
      </div>
    </div>
  );
}

export default Investment;
