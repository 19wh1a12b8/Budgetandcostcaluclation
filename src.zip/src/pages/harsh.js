import React from 'react';
import Grid from '@mui/material/Grid';
import '../Styles/harsh.css'

const harsh = () => {
  return (
    <div className="container">
      <div className="top-row">
        <div className="square-item grid1">Grid 1</div>
        <div className="square-item grid2">Grid 2</div>
      </div>
      <div className="bottom-row">
        <div className="square-item grid3">Grid 3</div>
        <div className="vertical-line"></div>
        <div className="square-item grid4">Grid 4</div>
        {/* <div className="vertical-line"></div> */}
        <div className="square-item grid5">Grid 5</div>
        <div className="vertical-line"></div>
        <div className="square-item grid6">Grid 6</div>
      </div>
    </div>
  );
};

export default harsh;
