import React from "react";
import  '../Styles/home.css';
// import "./YourCSSFile.css"; // Replace with the path to your CSS file

function Home() {
  return (
    <div className="container">
      <div className="avatar mt-5">
        <a href="https://codepen.io/MarioDesigns/">
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEuV0j14IleNLZbqSfufCsw-kBk39a31y9bg&usqp=CAU"
            alt="Skytsunami"
          />
        </a>
      </div>
      <div className="content">
        <h1>Welcome User</h1>
        {/* <p>Follow me on:</p> */}
        
        {/* <p>BY: Mario Duarte</p> */}
      </div>
    </div>
  );
}

export default Home;
