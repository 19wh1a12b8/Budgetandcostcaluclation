package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class FinancialCalculationService {
	   public double calculateLoanEMI(double principal, double annualInterestRate, int loanTenureMonths) {
	       double monthlyInterestRate = (annualInterestRate / 12) / 100;
	       double emi = principal * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, loanTenureMonths)
	                / (Math.pow(1 + monthlyInterestRate, loanTenureMonths) - 1);

	        return emi;
	    }

}

