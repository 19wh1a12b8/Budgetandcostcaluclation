package com.example.demo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Budget;
import com.example.demo.service.BudgetService;

@RestController
@RequestMapping("/budgets")
public class BudgetController {
    private final BudgetService budgetService;

    public BudgetController(BudgetService budgetService) {
        this.budgetService = budgetService;
    }

    @PostMapping("/createbudget")
    public ResponseEntity<Budget> createBudget(@RequestBody Budget budget) {
        Budget createdBudget = budgetService.createBudget(budget);
        return ResponseEntity.status(createdBudget != null ? HttpStatus.CREATED : HttpStatus.BAD_REQUEST)
                            .body(createdBudget);
    }

    

    @GetMapping("/{budgetId}")
    public ResponseEntity<Budget> getBudget(@PathVariable Long budgetId) {
        Budget budget = budgetService.getBudgetById(budgetId);
        return ResponseEntity.status(budget != null ? HttpStatus.OK : HttpStatus.NOT_FOUND)
                            .body(budget);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Budget>> getAllBudgetsByUser(@PathVariable Long userId) {
        List<Budget> budgets = budgetService.getAllBudgetsByUserId(userId);
        return ResponseEntity.status(!budgets.isEmpty() ? HttpStatus.OK : HttpStatus.NOT_FOUND)
                            .body(budgets);
    }

   
    @GetMapping("/calculateSpendingPercentage/{budgetId}")
    public ResponseEntity<Double> calculateBudgetCategorySpendingPercentage(@PathVariable Long budgetId) {
        double spendingPercentage = budgetService.calculateBudgetCategorySpendingPercentage(budgetId);
        return ResponseEntity.status(HttpStatus.OK).body(spendingPercentage);
    }}
