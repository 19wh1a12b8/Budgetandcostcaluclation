package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Portfolio;
import com.example.demo.repository.PortfolioRepository;

@Service
public class PortfolioService {

    @Autowired
    private PortfolioRepository portfolioRepository;

    public Portfolio createPortfolio(Portfolio portfolio) {
        return portfolioRepository.save(portfolio);
    }

    public Portfolio retrievePortfolio(Long portfolioId) {
       return portfolioRepository.findById(portfolioId).orElse(null);
    }

    public Portfolio updatePortfolio(Portfolio portfolio) {
    	if (portfolio.getPortfolioName() == null || portfolio.getPortfolioName().isEmpty()) {
            throw new IllegalArgumentException("Portfolio name is required.");
        }
    	if (portfolioRepository.existsByPortfolioName(portfolio.getPortfolioName())) {
            throw new IllegalArgumentException("Portfolio name must be unique.");
        }

        return portfolioRepository.save(portfolio);
    }

    public void deletePortfolio(Long portfolioId) {
        portfolioRepository.deleteById(portfolioId);
    }
}
