package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BccApplication {

	public static void main(String[] args) {
		SpringApplication.run(BccApplication.class, args);
	}

}
