package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Investment;
import com.example.demo.repository.InvestmentRepository;

@Service
public class InvestmentService {

    @Autowired
    private InvestmentRepository investmentRepository;

    public Investment createInvestment(Investment investment) {
        return investmentRepository.save(investment);
    }


    public double InvestmentGrowthProjectioncalculation(Investment investment, double annualInterestRate, int compoundingFrequency, int investmentPeriod) {
        double principal = investment.getPurchasePrice();
        double rate = annualInterestRate / 100; // Convert annual interest rate to decimal
        int n = compoundingFrequency;
        int t = investmentPeriod;

        double futureValue = principal * Math.pow((1 + rate / n), n * t);
        return futureValue;
    }


	public Investment retrieveInvestment(Long investmentId) {
		// TODO Auto-generated method stub
		return null;
	}
}
