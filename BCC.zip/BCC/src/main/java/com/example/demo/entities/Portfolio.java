package com.example.demo.entities;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Portfolio {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long portfolioId;

	@ManyToOne
	@JoinColumn(name = "userId")
	private User user;

	private String portfolioName;
	@OneToMany(mappedBy = "portfolio")
	private List<Investment> investments;

	public Portfolio(Long portfolioId, User user, String portfolioName, List<Investment> investments) {
		super();
		this.portfolioId = portfolioId;
		this.user = user;
		this.portfolioName = portfolioName;
		this.investments = investments;
	}

	public Portfolio() {
		super();

	}

	public Long getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Long portfolioId) {
		this.portfolioId = portfolioId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public List<Investment> getInvestments() {
		return investments;
	}

	public void setInvestments(List<Investment> investments) {
		this.investments = investments;
	}

	@Override
	public String toString() {
		return "Portfolio [portfolioId=" + portfolioId + ", user=" + user + ", portfolioName=" + portfolioName
				+ ", investments=" + investments + "]";
	}

}	