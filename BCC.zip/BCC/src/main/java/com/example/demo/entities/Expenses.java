package com.example.demo.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Expenses {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long expenseId;

    @ManyToOne
    @JoinColumn(name = "userId") 
    private User user;
    @ManyToOne
    @JoinColumn(name = "budgetId") 
    @JsonBackReference
    private Budget budget; 
    private String expenseCategory;
    private double amount;
    private Date date;
    private String description;
	
	public Expenses(Long expenseId, String expenseCategory, double amount, Date date, String description) {
		super();
		this.expenseId = expenseId;
		this.expenseCategory = expenseCategory;
		this.amount = amount;
		this.date = date;
		this.description = description;
	}
    
	
	public Long getExpenseId() {
		return expenseId;
	}


	public void setExpenseId(Long expenseId) {
		this.expenseId = expenseId;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Budget getBudget() {
		return budget;
	}


	public void setBudget(Budget budget) {
		this.budget = budget;
	}


	public String getExpenseCategory() {
		return expenseCategory;
	}


	public void setExpenseCategory(String expenseCategory) {
		this.expenseCategory = expenseCategory;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Override
	public String toString() {
		return "Expenses [expenseId=" + expenseId + ", expenseCategory=" + expenseCategory + ", amount=" + amount
				+ ", date=" + date + ", description=" + description + "]";
	}

	public Expenses() {
		super();
		// TODO Auto-generated constructor stub
	}

    
}