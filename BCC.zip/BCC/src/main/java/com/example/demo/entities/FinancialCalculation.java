package com.example.demo.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class FinancialCalculation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long calculationId;

	@ManyToOne
	@JoinColumn(name = "userId")
	private User user;

	private String calculationType;

	private Double principalAmount;
	private Double annualInterestRate;
	private Integer loanTenureInMonths;

	public Long getCalculationId() {
		return calculationId;
	}

	public void setCalculationId(Long calculationId) {
		this.calculationId = calculationId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getCalculationType() {
		return calculationType;
	}

	public void setCalculationType(String calculationType) {
		this.calculationType = calculationType;
	}

	public Double getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(Double principalAmount) {
		this.principalAmount = principalAmount;
	}

	public Double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(Double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}

	public Integer getLoanTenureInMonths() {
		return loanTenureInMonths;
	}

	public void setLoanTenureInMonths(Integer loanTenureInMonths) {
		this.loanTenureInMonths = loanTenureInMonths;
	}

	public FinancialCalculation(Long calculationId, User user, String calculationType, Double principalAmount,
			Double annualInterestRate, Integer loanTenureInMonths) {
		super();
		this.calculationId = calculationId;
		this.user = user;
		this.calculationType = calculationType;
		this.principalAmount = principalAmount;
		this.annualInterestRate = annualInterestRate;
		this.loanTenureInMonths = loanTenureInMonths;
	}

	public FinancialCalculation() {
		super();

	}

	@Override
	public String toString() {
		return "FinancialCalculation [calculationId=" + calculationId + ", user=" + user + ", calculationType="
				+ calculationType + ", principalAmount=" + principalAmount + ", annualInterestRate="
				+ annualInterestRate + ", loanTenureInMonths=" + loanTenureInMonths + "]";
	}

}