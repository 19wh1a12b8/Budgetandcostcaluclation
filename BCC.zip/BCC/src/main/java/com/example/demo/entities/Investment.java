package com.example.demo.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Investment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long investmentId;

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "portfolioId")
	private Portfolio portfolio;

	private Double purchasePrice;
	private Date purchaseDate;
	private int quantity;
	private String category;

	public Investment() {
		super();

	}

	public Investment(Long investmentId, Portfolio portfolio, Double purchasePrice, Date purchaseDate, int quantity,
			String category) {
		super();
		this.investmentId = investmentId;
		this.portfolio = portfolio;
		this.purchasePrice = purchasePrice;
		this.purchaseDate = purchaseDate;
		this.quantity = quantity;
		this.category = category;
	}

	public Long getInvestmentId() {
		return investmentId;
	}

	public void setInvestmentId(Long investmentId) {
		this.investmentId = investmentId;
	}

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public Double getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(Double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Investment [investmentId=" + investmentId + ", portfolio=" + portfolio + ", purchasePrice="
				+ purchasePrice + ", purchaseDate=" + purchaseDate + ", quantity=" + quantity + ", category=" + category
				+ "]";
	}

}
