package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Expenses;
import com.example.demo.repository.ExpensesRepository;

@Service
public class ExpensesService {
	@Autowired
	private ExpensesRepository expenseRepository;

	public Expenses createExpense(Expenses expense) {
		return expenseRepository.save(expense);
	}

	

	public double calculateExpenseCategorySpendingPercentage(String expenseCategory) {
		Iterable<Expenses> expensesInCategoryIterable = expenseRepository.findAllByExpenseCategory(expenseCategory);
		List<Expenses> expensesInCategory = new ArrayList<>();
		expensesInCategoryIterable.forEach(expensesInCategory::add);
		double totalExpensesInCategory = expensesInCategory.stream().mapToDouble(Expenses::getAmount).sum();
		Iterable<Expenses> allExpensesIterable = expenseRepository.findAll();
		List<Expenses> allExpenses = new ArrayList<>();
		allExpensesIterable.forEach(allExpenses::add);
		double totalAllExpenses = allExpenses.stream().mapToDouble(Expenses::getAmount).sum();

		if (totalAllExpenses > 0) {
			return (totalExpensesInCategory / totalAllExpenses) * 100;
		} else {

			return 0;
		}
	}

}