package com.example.demo.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Expenses;
import com.example.demo.entities.User;

public interface ExpensesRepository extends JpaRepository<Expenses, Long> {

	BigDecimal calculateTotalExpensesInCategory(String expenseCategory, User user);

	double calculateTotalExpensesAmountByCategory(String expenseCategory);

	Iterable<Expenses> findAllByExpenseCategory(String expenseCategory);

	List<Expenses> findAllByBudget_BudgetId(Long budgetId);

	List<Expenses> findAllByUser_UserId(Long userId);

}
