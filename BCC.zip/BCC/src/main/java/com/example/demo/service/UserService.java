package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public User createUser(User user) {
		return userRepository.save(user);
	}

	public User retrieveUser(Long userId) {
		return userRepository.findById(userId).orElse(null);
	}

	public User updateUser(User user) {
		return userRepository.save(user);
	}

	public void deleteUser(Long userId) {
		userRepository.deleteById(userId);
	}

	public User updateUserProfile(Long userId, User updatedUser) {
		User existingUser = userRepository.findById(userId).orElse(null);

		if (existingUser != null) {
			existingUser.setUsername(updatedUser.getUsername());
			return userRepository.save(existingUser);
		} else {
			return null;
		}
	}
}