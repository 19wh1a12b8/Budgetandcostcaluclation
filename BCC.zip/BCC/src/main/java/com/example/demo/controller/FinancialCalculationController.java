package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.FinancialCalculationService;

@RestController
@RequestMapping("/financial")
public class FinancialCalculationController {

    @Autowired
    private FinancialCalculationService financialCalculationService;
    
    
    @GetMapping("/emi")
    public double calculateLoanEMI(
            @RequestParam double principal,
            @RequestParam double annualInterestRate,
            @RequestParam int loanTenureMonths) {
        return financialCalculationService.calculateLoanEMI(principal, annualInterestRate, loanTenureMonths);
    }
}