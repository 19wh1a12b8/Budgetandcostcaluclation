package com.example.demo.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Budget {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long budgetId;

	@ManyToOne
	@JoinColumn(name = "userId")
	private User user;

	private String budgetCategory;
	private Double allocatedAmount;
	
	@JsonManagedReference
	@OneToMany(mappedBy = "budget")
	private List<Expenses> expenses;

	public Budget(Long budgetId, User user, String budgetCategory, Double allocatedAmount, List<Expenses> expenses) {
		super();
		this.budgetId = budgetId;
		this.user = user;
		this.budgetCategory = budgetCategory;
		this.allocatedAmount = allocatedAmount;
		this.expenses = expenses;
	}

	public Budget() {
		super();
		
	}

	public Long getBudgetId() {
		return budgetId;
	}

	public void setBudgetId(Long budgetId) {
		this.budgetId = budgetId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getBudgetCategory() {
		return budgetCategory;
	}

	public void setBudgetCategory(String budgetCategory) {
		this.budgetCategory = budgetCategory;
	}

	public Double getAllocatedAmount() {
		return allocatedAmount;
	}

	public void setAllocatedAmount(Double allocatedAmount) {
		this.allocatedAmount = allocatedAmount;
	}

	public List<Expenses> getExpenses() {
		return expenses;
	}

	public void setExpenses(List<Expenses> expenses) {
		this.expenses = expenses;
	}

	@Override
	public String toString() {
		return "Budget [budgetId=" + budgetId + ", user=" + user + ", budgetCategory=" + budgetCategory
				+ ", allocatedAmount=" + allocatedAmount + ", expenses=" + expenses + "]";
	}

}
