package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Budget;
import com.example.demo.entities.Expenses;
import com.example.demo.repository.BudgetRepository;
import com.example.demo.repository.ExpensesRepository;
import com.example.demo.repository.UserRepository;

@Service
public class BudgetService {

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private ExpensesRepository expenseRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    
    public double NetSavingscalculation(Long userId) {
    	List<Expenses> allExpenses = expenseRepository.findAllByUser_UserId(userId);
       List<Budget> budgets = budgetRepository.findAllByUser_UserId(userId);
        
        
      
        
        
        double totalBudgetedAmount = budgets.stream().mapToDouble(Budget::getAllocatedAmount).sum();
        double totalExpenses = allExpenses.stream().mapToDouble(Expenses::getAmount).sum();

       return totalBudgetedAmount - totalExpenses;
    }

    

    public Budget createBudget(Budget budget) {
        return budgetRepository.save(budget);
    }
    public Budget getBudgetById(Long budgetId) {
        return budgetRepository.findById(budgetId).orElse(null);
    }

    public List<Budget> getAllBudgetsByUserId(Long userId) {
        return budgetRepository.findAllByUser_UserId(userId);
    }



  
    public double calculateBudgetCategorySpendingPercentage(Long budgetId) {
        Budget budget = budgetRepository.findById(budgetId).orElse(null);
        
        if (budget != null) {
            List<Expenses> expenses = expenseRepository.findAllByBudget_BudgetId(budgetId);
            double totalExpenses = expenses.stream().mapToDouble(Expenses::getAmount).sum();
            double allocatedAmount = budget.getAllocatedAmount();
            
            if (allocatedAmount > 0) {
            	
                double percentage;
				return  percentage = (totalExpenses / allocatedAmount) * 100;
            }
        }
        return 0.0; 
    }    
}
