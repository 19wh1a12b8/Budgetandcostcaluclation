// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../Styles/Register.css';

// const Register = () => {
//   const navigate = useNavigate();
//   const [username, setUsername] = useState('');
//   const [password, setPassword] = useState('');
//   const [emailId, setEmailId] = useState('');
//   const [error, setError] = useState('');
//   const [validationError, setValidationError] = useState('');

//   const handleUsernameChange = (e) => {
//     setUsername(e.target.value);
//   };

//   const handlePasswordChange = (e) => {
//     setPassword(e.target.value);
//   };


//   const handleMailIdChange = (e) => {
//     setEmailId(e.target.value);
//   };

//   const validateForm = () => {
//     if (!username || !password || !emailId) {
//       setValidationError('All fields are required.');
//       return false;
//     }
//     setValidationError('');
//     return true;
//   };

//   const register = async () => {
//     const isValid = validateForm();

//     if (!isValid) {
//       return;
//     }

//     const user = {
//       name: username,
//       password: password,
//       emailId: emailId
//     };

//     try {
//       // Replace with the actual API endpoint for user registration
//       const apiUrl = `http://localhost:8089/api/users/create`;

//       const response = await fetch(apiUrl, {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(user),
//       });

//       if (response.status === 200) {
//         // Registration successful, display success message
//         setError('Registration successful. Please login.');
//         navigate('/login');
//       } else {
//         // Registration failed, display error message
//         setError('Registration failed. Please try again.');
//         navigate('/register');
//       }
//     } catch (error) {
//       console.log(error);
//       setError('An error occurred during registration');
//     }
//   };

//   const handleRegistration = (e) => {
//     e.preventDefault();
//     register();
//   };

//   return (
//     <>
//      <div className="register-container">
//     <div className='register-card'>
//       <div style={{ width: "700px", marginLeft: "270px" }}>
//         <div className="container mt-5" style={{ marginLeft: "50px" }}>
//           <h1 className="text-center mb-4" style={{ fontSize: "30px", color: "white", paddingRight: "300px" }}>Register Here!</h1>
//           <form onSubmit={handleRegistration}>
//             <div className="mb-3">
//               <label className="form-label" style={{ color: "white" }}>Username</label>
//               <input type="text" className="form-control" value={username} onChange={handleUsernameChange} style={{ width: "250px" }} />
//             </div>
            
//             <div className="mb-3">
//               <label className="form-label" style={{ color: "white" }}>Mail Id</label>
//               <input type="email" className="form-control" value={emailId} onChange={handleMailIdChange} style={{ width: "250px" }} />
//             </div>
//             <div className="mb-3">
//               <label className="form-label" style={{ color: "white" }}>Password</label>
//               <input type="password" className="form-control" value={password} onChange={handlePasswordChange} style={{ width: "250px" }} />
//             </div>
//             <button type="submit" className="btn btn-primary" style={{ color: "white" }}>Register</button><br /> <br />
//             <button type="submit" className="btn btn-primary" style={{ color: "white" }} onClick={() => navigate("/login")}>Already Have an account</button>
//             {validationError && <p className="text-danger mt-2">{validationError}</p>}
//             {error && <p className="text-danger mt-2">{error}</p>}
//           </form>
//         </div>
//       </div>
//       </div>
//       </div>
//     </>
//   );
// };

// export default Register;