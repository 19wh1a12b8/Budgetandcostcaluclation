import React, { useState } from 'react';
import '../Styles/LoanCalculator.css' // Import the CSS file

const LoanCalculator = () => {
  const [principal, setPrincipal] = useState(10000);
  const [annualInterestRate, setAnnualInterestRate] = useState(6);
  const [loanTenureMonths, setLoanTenureMonths] = useState(12);
  const [emi, setEmi] = useState(0);

  const calculateEMI = () => {
    // Fetch the EMI from the backend
    fetch(`http://localhost:8281/financial/emi?principal=${principal}&annualInterestRate=${annualInterestRate}&loanTenureMonths=${loanTenureMonths}`)
      .then((response) => response.json())
      .then((data) => {
        setEmi(data);
        console.log(data);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="card-container  "> {/* Center align the card */}
      <div className="card ">
        <h2>Loan EMI Calculator</h2>
        <label className='text-start' >Principal Amount:</label>
        <input type="number" value={principal} onChange={(e) => setPrincipal(e.target.value)} />
        <label className='text-start' >Annual Interest Rate (%):</label>
        <input type="number" value={annualInterestRate} onChange={(e) => setAnnualInterestRate(e.target.value)} />
        <label className='text-start'>Loan Tenure (Months):</label>
        <input type="number" value={loanTenureMonths} onChange={(e) => setLoanTenureMonths(e.target.value)} />
        <button onClick={calculateEMI}>Calculate EMI</button>
        {emi > 0 && <p>EMI: {emi}</p>}
      </div>
    </div>
  );
};

export default LoanCalculator;
