import React, { useState, useEffect } from 'react';
import '../Styles/Expenses.css'

function ExpenseCategorySpending() {
  const [spendingPercentage, setSpendingPercentage] = useState(null);
  const [error, setError] = useState(null);
  const [expenseCategory, setExpenseCategory] = useState('Food'); // Initialize with your desired expense category

  const fetchSpendingPercentage = () => {
    // Define the API URL
    const apiUrl = `http://localhost:8281/expenses/spendingPercentage/${expenseCategory}`;

    // Make the API request
    fetch(apiUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        setSpendingPercentage(data);
        setError(null); // Clear any previous errors
      })
      .catch((error) => {
        setSpendingPercentage(null);
        setError('Error fetching data. Please check your input and try again.');
        console.error('Error fetching data:', error);
      });
  };

  return (
    <div className="card-container">
      <div className="card">
        <h2>Expense Category Spending Percentage</h2>
        <div>
          <label>Expense Category:</label>
          <input
            type="text"
            value={expenseCategory}
            onChange={(e) => setExpenseCategory(e.target.value)}
          />
        </div>
        <div>
          {error ? <p className="error-message">{error}</p> : null}
          {spendingPercentage !== null ? (
            <>
              <p>Spending Percentage: {spendingPercentage}%</p>
              {/* <p>No Category found</p> */}
            </>
          ) : (
            <p>Click the "Fetch Spending percentage" button to see the result.</p>
          )}
        </div>
        <button type="button" onClick={fetchSpendingPercentage}>
          Fetch Spending percentage
        </button>
      </div>
    </div>
  );
}

export default ExpenseCategorySpending;

// import React, { useState, useEffect } from 'react';
// import '../Styles/Expenses.css'

// function ExpenseCategorySpending() {
//   const [spendingPercentage, setSpendingPercentage] = useState(null);
//   const [error, setError] = useState(null);
//   const [expenseCategory, setExpenseCategory] = useState('Food'); // Initialize with your desired expense category

//   useEffect(() => {
//     // Define the API URL
//     const apiUrl = `http://localhost:8281/expenses/spendingPercentage/${expenseCategory}`;

//     // Make the API request
//     fetch(apiUrl)
//       .then((response) => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then((data) => {
//         setSpendingPercentage(data);
//         setError(null); // Clear any previous errors
//       })
//       .catch((error) => {
//         setSpendingPercentage(null);
//         setError('Error fetching data. Please check your input and try again.');
//         console.error('Error fetching data:', error);
//       });
//   }, [expenseCategory]);

//   return (
//     <div className="card-container">
//     <div className="card">
//       <h2>Expense Category Spending Percentage</h2>
//       <div>
//         <label>Expense Category:</label>
//         <input
//           type="text"
//           value={expenseCategory}
//           onChange={(e) => setExpenseCategory(e.target.value)}
//         />
//       </div>
//       <div>
//         {error ? <p className="error-message">{error}</p> : null}
//         {spendingPercentage !== null ? (<>
//           <p>Spending Percentage: {spendingPercentage}%</p>
//           {/* <p>No Category found</p> */}
//           </>
//         ) : (
//           <p>Click the "Fetch" button to see the result.</p>
//         )}
//       </div>
//       <button type="submit">Fetch Spending percentage</button>
//     </div>
//   </div>
// );
// }

// export default ExpenseCategorySpending;
