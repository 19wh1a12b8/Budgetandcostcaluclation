import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Styles/Budget.css'; // Import a CSS file for styling

function Budget() {
  const [budgetId, setBudgetId] = useState('');
  const [spendingPercentage, setSpendingPercentage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleBudgetIdChange = (event) => {
    setBudgetId(event.target.value);
  };

  const fetchSpendingPercentage = () => {
    setLoading(true);
    setError(null); // Reset any previous errors

    axios
      .get(`http://localhost:8281/budgets/calculateSpendingPercentage/${budgetId}`)
      .then((response) => {
        console.log('API Response:', response);
        if (response.data === 0) {
          setSpendingPercentage('Budget ID not found');
        } else {
          setSpendingPercentage(response.data + '%');
        }
      })
      .catch((error) => {
        setSpendingPercentage(null);
        setError('Error fetching spending percentage. Please check your input and try again.');
        console.error('Error fetching spending percentage:', error);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <div className="budget-container"> {/* Center align the card */}
      <div className="budget-card"> {/* Apply styles to the card */}
        <h2>Budget Spending Percentage</h2>
        <div>
          <label>Enter Budget ID:</label>
          <input type="text" value={budgetId} onChange={handleBudgetIdChange} />
        </div>
        <div>
          <button onClick={fetchSpendingPercentage}>Fetch Spending Percentage</button>
        </div>
        <div>
          {loading ? <p>Loading...</p> : null}
          {error ? <p>{error}</p> : null}
          {spendingPercentage !== null ? <p>{spendingPercentage}</p> : null}
        </div>
      </div>
    </div>
  );
}

export default Budget;
