import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../Styles/Net.css';

const NetSavings = () => {
  const [netSavings, setNetSavings] = useState(null);
  const [error, setError] = useState(null);
  const { userId } = useParams();
  const [inpId, setinpId] = useState(userId || '');

  const func = (Id) => {
    fetch(`http://localhost:8281/budgets/calculateNetSavings/${Id}`)
      .then((response) => {
        if (!response.ok) {
          if (response.status === 404) {
            setError('User ID does not exist in the database');
          } else {
            throw new Error('Network response was not ok');
          }
        } else {
          return response.json();
        }
      })
      .then((data) => {
        setNetSavings(data);
      })
      .catch((error) => {
        setError('An error occurred. Please try again.');
        console.error(error);
      });
  };

  const handleShowNetSavings = () => {
    if (inpId) {
      setError(null); // Reset the error when making a new request
      func(inpId);
    }
  };

  return (
    <div className="card-container">
      <div className="card">
        <h2>Net Savings</h2>
        <input
          type="text"
          placeholder="Enter user ID"
          value={inpId}
          onChange={(e) => setinpId(e.target.value)}
        />
        <button onClick={handleShowNetSavings}>Show Net Savings</button>

        {error && <p className="error-message">{error}</p>}
        {netSavings !== null && (
          <p>Net Savings: {netSavings !== 0 ? netSavings : 'User ID not found'}</p>
        )}
      </div>
    </div>
  );
};

export default NetSavings;
